<div class="middle">
		<div class="container">
			<div class="page_title_wrapper">
				<h1 class="page_title">Поддержка</h1>
			</div>
			<div class="about_menu">
				<div class="block_content">
					<ul class="menu">
						<li><a href="#">E-mail поддержка</a></li>
						<li><a href="#">Вопросы и ответы</a></li>
						<li><a href="#">Демос</a></li>
						<li><a class="active" href="#">Свяжитесь с нами</a></li>
					</ul>
				</div>
			</div>
			<div class="middle_content clearfix">
				<div id="contacts_map" class="map_canvas map_canvas_contacs" data-coordinate="45.487505, 9.202499"></div>
				<div class="contacts_block">
					<div class="col">
						<div class="title">Адрес:</div>
						<div class="field_content">Blend Tower, Piazza Quattro, <br> Novembre 7, 20124, Milano, ITALY</div>
					</div>
					<div class="col">
						<div class="title">Телефон:</div>
						<div class="field_content"><a href="tel:+390287343435">+39 02 87 34 34 35</a></div>
					</div>
					<div class="col">
						<div class="title">Эл. адрес:</div>
						<div class="field_content"><a href="mailto:admin@lnsinvest.net">admin@lnsinvest.net</a></div>
					</div>
					<div class="col">
						<div class="title">Поддерджка</div>
						<div class="field_content"><a href="mailto:support@lnsinvest.net">support@lnsinvest.net</a></div>
					</div>
				</div>
			</div>
		</div>
	</div>