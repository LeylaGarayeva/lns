<div class="middle">
		<div class="container">
			<div class="page_title_wrapper">
				<h1 class="page_title">Как это работает</h1>
			</div>
			<div class="about_menu">
				<div class="block_content">
					<ul class="menu">
						<li><a class="active" href="#">Войти в систему</a></li>
						<li><a href="#">Политика возврата</a></li>
						<li><a href="#">Правила</a></li>
						<li><a href="#">Условия и положения</a></li>
					</ul>
				</div>
			</div>
			<div class="middle_content clearfix">
				<div class="work_wrap">
					<div class="text">
						 К услугам покупателей часов LNS все функции веб-сайта, помогающие сделать верный выбор часов экстра-класса. В этом кроется единственная причина успеха компании LNS, стремящейся к постоянному расширению ассортимента, не требуя ничего взамен.
					</div>
					<div class="register_form">
						<div class="block_title">Войти в систему:</div>
						<form action="#">
							<div class="form_item">
								<label for="">Электронный адрес:</label>
								<input type="email" class="form_text">
							</div>
							<div class="form_item">
								<label for="">Пароль:</label>
								<input type="password" class="form_text">
							</div>
							<div class="form_actions">
								<a href="#">Забыли пароль?</a>
								<input type="submit" class="form_submit" value="Войти">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>