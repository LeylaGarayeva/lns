<div class="middle">
		<div class="container">
			<div class="page_title_wrapper">
				<h1 class="page_title">Корзина</h1>
			</div>
			<div class="middle_content">
				<section class="basket_check">
				    <div class="basket_check_list">
				        <div class="basket_check_list_title">Товар</div>
				        <div class="basket_check_list_title">Цена, руб</div>
				        <div class="basket_check_list_title">Количество</div>
				        <div class="basket_check_list_title">Сумма, руб</div>
				    </div>
				    <div class="basket_check_items">
				        <div class="basket_check_items_item">
				            <div class="basket_check_items_item_photo"><img src="images/basket_1.png" alt=""></div>
				            <div class="basket_check_items_item_title">
				                <div class="item_name">Bottega Veneta Eau Legere EDT Eau De Toilette Spray 30ml/1oz Perfume</div>
				                <div class="item_article">Артикул: <span>45971644</span></div>
				            </div>
				            <div class="basket_check_items_item_price">2 256</div>
				            <div class="basket_check_items_item_counter">
				                <div class="good_basket clearfix">
				                    <div class="good_basket_btns clearfix">
				                        <div class="good_basket_min"></div>
				                        <input type="text" class="good_basket_input form_text" value="1">
				                        <div class="good_basket_plus"></div>
				                    </div>
				                </div>
				            </div>
				            <div class="basket_check_items_item_total">2 256</div>
				            <div class="item_close"><img src="images/close-icon.png" alt=""></div>
				        </div>
				         <div class="basket_check_items_item">
				            <div class="basket_check_items_item_photo"><img src="images/basket_2.png" alt=""></div>
				            <div class="basket_check_items_item_title">
				                <div class="item_name">Bottega Veneta Eau Legere EDT Eau De Toilette Spray 30ml/1oz Perfume</div>
				                <div class="item_article">Артикул: <span>45971644</span></div>
				            </div>
				            <div class="basket_check_items_item_price">2 256</div>
				            <div class="basket_check_items_item_counter">
				                <div class="good_basket clearfix">
				                    <div class="good_basket_btns clearfix">
				                        <div class="good_basket_min"></div>
				                        <input type="text" class="good_basket_input form_text" value="1">
				                        <div class="good_basket_plus"></div>
				                    </div>
				                </div>
				            </div>
				            <div class="basket_check_items_item_total">2 256</div>
				            <div class="item_close"><img src="images/close-icon.png" alt=""></div>
				        </div>
				         <div class="basket_check_items_item">
				            <div class="basket_check_items_item_photo"><img src="images/basket_3.png" alt=""></div>
				            <div class="basket_check_items_item_title">
				                <div class="item_name">Bottega Veneta Eau Legere EDT Eau De Toilette Spray 30ml/1oz Perfume</div>
				                <div class="item_article">Артикул: <span>45971644</span></div>
				            </div>
				            <div class="basket_check_items_item_price">2 256</div>
				            <div class="basket_check_items_item_counter">
				                <div class="good_basket clearfix">
				                    <div class="good_basket_btns clearfix">
				                        <div class="good_basket_min"></div>
				                        <input type="text" class="good_basket_input form_text" value="1">
				                        <div class="good_basket_plus"></div>
				                    </div>
				                </div>
				            </div>
				            <div class="basket_check_items_item_total">2 256</div>
				            <div class="item_close"><img src="images/close-icon.png" alt=""></div>
				        </div>
				    </div>
				    <div class="basket_controls">
				        <div class="basket_controls_goback"><a href="#">Продолжить покупки</a></div>
				        <div class="basket_sum">
				           	<div class="total_price_wrap">
           			            <div class="basket_sum_total"><span>Сумма вашего заказа:</span>
           		                <div class="total_price">4 561 <span>руб</span></div>
				           	</div>
				            <div class="basket_sum_submit">
				                <input type="submit" value='Оформить заказ'>
				            </div>
				        </div>
				    </div>
				</section>
			</div>
		</div>
	</div>