				<header class="header">
					<!-- <a id="hamburger" href="#my-menu"><span>Меню</span></a> -->
					<a href="#menu" id="hamburger" class="mm-slideout">
						<span class="hamburger hamburger--collapse">
							<span class="hamburger-box">
								<span class="hamburger-inner"></span>
							</span>
						</span>
					</a>
					<div class="header_content clearfix">
						<div class="logo"><a href="/"><img src="images/logo.png" alt="LNS | Вместе для лучшей жизни" title="LNS | Вместе для лучшей жизни"></a></div>
						<div class="head_wrap">
							<div class="slogan">Продукция, ведущая к успеху!</div>
							<div class="block_wrap">
								<div class="block_language">
									<form action="#">
										<select>
											<option selected value="Рус">Рус</option>
											<option value="Eng">Eng</option>
										</select>
									</form>
								</div>
								<div class="block_search">
									<div class="search_btn">Поиск</div>
									<form action="#">
										<div class="form_item"><input type="text" class="form_text" placeholder="Введите слова для поиска"></div>
										<input type="submit" class="form_submit" value="Поиск">
									</form>
									<div class="popup_fon3"></div>
								</div>
								<div class="user_link"><a href="#">Мой профиль</a></div>
							</div>
							<div class="basket_header">
								<a class="basket_link" href="#"></a>
								<span class="title">Корзина</span>
								<span class="order">Заказать <span>(1)</span></span>
							</div>
						</div>
					</div>
					<div class="header_container">
						<div class="header_content clearfix">
							<ul class="menu" id="menu">
								<li><a href="#">О компании</a></li>
								<li><a href="#">Как это работает?</a></li>
								<li><a href="#">Продукция</a></li>
								<li><a href="#">Возможности</a></li>
								<li><a href="#">Новости</a></li>
								<li><a href="#">Поддержка</a></li>
							</ul>
						</div>
					</div>
				</header>