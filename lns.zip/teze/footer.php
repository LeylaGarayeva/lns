			<footer class="footer">
				<div class="footer_content clearfix">
					<div class="social_links">
						<a href="#" class="social social_1">Facebook</a>
						<a href="#" class="social social_2">Instagram</a>
						<a href="#" class="social social_3">Twitter</a>
						<a href="#" class="social social_4">Youtube</a>
						<a href="#" class="social social_5">Pinterest</a>
					</div>
					<div class="logo_wrapper">
						<div class="logo"><a href="/"><img src="images/logo_footer.png" alt="LNS | Вместе для лучшей жизни" title="LNS | Вместе для лучшей жизни"></a></div>
						<div class="copyright">© 2014-2017  |  Все права защищены<br>LNS INTERNATIONAL SRL <br>C.F/P.IVA 08165340962</div>
						<div id="gl_devel">
							<span><img src="/images/g.png" alt="">Глянец</span> – <a href="http://glyanec.net/" onclick="window.open(this.href); return false">Разработка сайтов</a>
						</div>
					</div>
					<div class="menu_wrapper clearfix">
						<div class="block_menu">
							<div class="title">О компании</div>
							<ul class="menu menu_1">
								<li><a href="#">О LNS</a></li>
								<li><a href="#">Менеджмент</a></li>
								<li><a href="#">Бизнес регистрация</a></li>
								<li><a href="#">Банковские реквизиты</a></li>
							</ul>				
						</div>
						<div class="block_menu">
							<div class="title">Как это работает?</div>
							<ul class="menu menu_1">
								<li><a href="#">Войти в систему</a></li>
								<li><a href="#">Политика возврата</a></li>
								<li><a href="#">Правила</a></li>
								<li><a href="#">Условия и положения</a></li>
							</ul>
						</div>
						<div class="block_menu">
							<div class="title">Продукция</div>
							<ul class="menu menu_1">
								<li><a href="#">Вся продукция</a></li>
								<li><a href="#">Часы</a></li>
							</ul>
							<div class="title"><a href="#">Новости</a></div>
						</div>
						<div class="block_menu">
							<div class="title">Возможности</div>
							<ul class="menu menu_1">
								<li><a href="#">План возмещения</a></li>
								<li><a href="#">Прямые продажи</a></li>
								<li><a href="#">Возможности клиента</a></li>
								<li><a href="#">Информация о продуктах</a></li>
								<li><a href="#">Истории успеха</a></li>
							</ul>					
						</div>
						<div class="block_menu">
							<div class="title">Поддержка</div>
							<ul class="menu menu_1">
								<li><a href="#">E-mail поддержка</a></li>
								<li><a href="#">Вопросы и ответы</a></li>
								<li><a href="#">Демос</a></li>
								<li><a href="#">Свяжитесь с нами</a></li>
							</ul>					
						</div>
					</div>
				</div>
			</footer>