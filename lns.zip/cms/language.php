<?PHP

// Menu start
$dil['menu1']['az']="Sayta bax";
$dil['menu1']['ru']="Sayta bax";
$dil['menu1']['en']="Sayta bax";

$dil['menu2']['az']="Paneldən çıx";
$dil['menu2']['ru']="Paneldən çıx";
$dil['menu2']['en']="Paneldən çıx";

$dil['menu3']['az']="Admin";
$dil['menu3']['ru']="Admin";
$dil['menu3']['en']="Admin";

$dil['menu4']['az']="Adminlər";
$dil['menu4']['ru']="Adminlər";
$dil['menu4']['en']="Adminlər";

$dil['menu5']['az']="Dil";
$dil['menu5']['ru']="Dil";
$dil['menu5']['en']="Dil";

$dil['menu6']['az']="Sayt";
$dil['menu6']['ru']="Sayt";
$dil['menu6']['en']="Sayt";

$dil['menu7']['az']="Səhifələr";
$dil['menu7']['ru']="Səhifələr";
$dil['menu7']['en']="Səhifələr";

$dil['menu8']['az']="Yuxarı";
$dil['menu8']['ru']="Yuxarı";
$dil['menu8']['en']="Yuxarı";

$dil['menu9']['az']="Aşağı";
$dil['menu9']['ru']="Aşağı";
$dil['menu9']['en']="Aşağı";

$dil['menu10']['az']="Gizli";
$dil['menu10']['ru']="Gizli";
$dil['menu10']['en']="Gizli";

$dil['menu11']['az']="Yuxarı slider";
$dil['menu11']['ru']="Yuxarı slider";
$dil['menu11']['en']="Yuxarı slider";

$dil['menu12']['az']="Xəbərlər";
$dil['menu12']['ru']="Xəbərlər";
$dil['menu12']['en']="Xəbərlər";
$dil['yeni_xeber']['az']="Yeni xəbər";
$dil['yeni_xeber']['ru']="Yeni xəbər";
$dil['yeni_xeber']['en']="Yeni xəbər";

$dil['menu13']['az']="Qalereya";
$dil['menu13']['ru']="Qalereya";
$dil['menu13']['en']="Qalereya";$dil['yeni_qalereya']['az']="Yeni qalereya";$dil['yeni_qalereya']['ru']="Yeni qalereya";$dil['yeni_qalereya']['en']="Yeni qalereya";

$dil['menu14']['az']="Məhsullar";
$dil['menu14']['ru']="Məhsullar";
$dil['menu14']['en']="Məhsullar";

$dil['turlar']['az']="Turlar";
$dil['turlar']['ru']="Turlar";
$dil['turlar']['en']="Turlar";

$dil['novbeti']['az']="Növbəti";
$dil['novbeti']['ru']="Növbəti";
$dil['novbeti']['en']="Növbəti";


$dil['otel']['az']="Otellər";
$dil['otel']['ru']="Otellər";
$dil['otel']['en']="Otellər";

$dil['menu15']['az']="Kateqoriyalar";
$dil['menu15']['ru']="Kateqoriyalar";
$dil['menu15']['en']="Kateqoriyalar";

//Menu end


$dil['welcome_title']['az']="Xoş gəlmisiniz !";
$dil['welcome_title']['ru']="Xoş gəlmisiniz !";
$dil['welcome_title']['en']="Xoş gəlmisiniz !";

$dil['welcome_message']['az']="2 Mesajınız var";
$dil['welcome_message']['ru']="2 Mesajınız var";
$dil['welcome_message']['en']="2 Mesajınız var";

$dil['statistika_title']['az']="Statistika";
$dil['statistika_title']['ru']="Statistika";
$dil['statistika_title']['en']="Statistika";

$dil['statistika_select']['az']="Seç";
$dil['statistika_select']['ru']="Seç";
$dil['statistika_select']['en']="Seç";

$dil['statistika_select1']['az']="Son 1 ay";
$dil['statistika_select1']['ru']="Son 1 ay";
$dil['statistika_select1']['en']="Son 1 ay";

$dil['statistika_select2']['az']="Son 1 həfdə";
$dil['statistika_select2']['ru']="Son 1 həfdə";
$dil['statistika_select2']['en']="Son 1 həfdə";

$dil['statistika_select3']['az']="Son 24 saat";
$dil['statistika_select3']['ru']="Son 24 saat";
$dil['statistika_select3']['en']="Son 24 saat";

$dil['statistika_select4']['az']="Son 3 dəqiqə";
$dil['statistika_select4']['ru']="Son 3 dəqiqə";
$dil['statistika_select4']['en']="Son 3 dəqiqə";

//yuxari

$dil['Linklər']['az']="Linklər";
$dil['Linklər']['ru']="Linklər";
$dil['Linklər']['en']="Linklər";

$dil['link']['az']="link";
$dil['link']['ru']="link";
$dil['link']['en']="link";

$dil['Yeni_səhifə']['az']="Yeni səhifə";
$dil['Yeni_səhifə']['ru']="Yeni səhifə";
$dil['Yeni_səhifə']['en']="Yeni səhifə";

$dil['Yadda_saxla']['az']="Yadda saxla";
$dil['Yadda_saxla']['ru']="Yadda saxla";
$dil['Yadda_saxla']['en']="Yadda saxla";

$dil['Sil']['az']="Sil";
$dil['Sil']['ru']="Sil";
$dil['Sil']['en']="Sil";

$dil['Aktiv']['az']="Aktiv";
$dil['Aktiv']['ru']="Aktiv";
$dil['Aktiv']['en']="Aktiv";

$dil['Passiv']['az']="Passiv";
$dil['Passiv']['ru']="Passiv";
$dil['Passiv']['en']="Passiv";

$dil['Yuxari_Sehifeler']['az']="Yuxari Sehifeler";
$dil['Yuxari_Sehifeler']['ru']="Yuxari Sehifeler";
$dil['Yuxari_Sehifeler']['en']="Yuxari Sehifeler";

$dil['Cedvel']['az']="Cedvel";
$dil['Cedvel']['ru']="Cedvel";
$dil['Cedvel']['en']="Cedvel";

$dil['Id']['az']="Id";
$dil['Id']['ru']="Id";
$dil['Id']['en']="Id";

$dil['Ad']['az']="Ad";
$dil['Ad']['ru']="Ad";
$dil['Ad']['en']="Ad";

$dil['Istifadeci_adi']['az']="Istifadeci adi";
$dil['Istifadeci_adi']['ru']="Istifadeci adi";
$dil['Istifadeci_adi']['en']="Istifadeci adi";

$dil['Idare']['az']="Idare";
$dil['Idare']['ru']="Idare";
$dil['Idare']['en']="Idare";

$dil['Videolar']['az']="Videolar";
$dil['Videolar']['ru']="Videolar";
$dil['Videolar']['en']="Videolar";

$dil['Yeni_video']['az']="Yeni video";
$dil['Yeni_video']['ru']="Yeni video";
$dil['Yeni_video']['en']="Yeni video";

$dil['Yeni_slider']['az']="Yeni slider";
$dil['Yeni_slider']['ru']="Yeni slider";
$dil['Yeni_slider']['en']="Yeni slider";

$dil['Sol_Sehifeler']['az']="Sol Sehifeler";
$dil['Sol_Sehifeler']['ru']="Sol Sehifeler";
$dil['Sol_Sehifeler']['en']="Sol Sehifeler";

$dil['Admin  /  Sayt']['az']="Admin  /  Sayt";
$dil['Admin  /  Sayt']['ru']="Admin  /  Sayt";
$dil['Admin  /  Sayt']['en']="Admin  /  Sayt";

$dil['Dəyiş']['az']="Dəyiş";
$dil['Dəyiş']['ru']="Dəyiş";
$dil['Dəyiş']['en']="Dəyiş";

$dil['On/Off']['az']="On/Off";
$dil['On/Off']['ru']="On/Off";
$dil['On/Off']['en']="On/Off";

$dil['Title']['az']="title";
$dil['Title']['ru']="title";
$dil['Title']['en']="title";

$dil['edit']['az']="edit";
$dil['edit']['ru']="edit";
$dil['edit']['en']="edit";

$dil['Yeni_məhsul']['az']="Yeni məhsul";
$dil['Yeni_məhsul']['ru']="Yeni məhsul";
$dil['Yeni_məhsul']['en']="Yeni məhsul";

$dil['Cədvəl']['az']="Cədvəl";
$dil['Cədvəl']['ru']="Cədvəl";
$dil['Cədvəl']['en']="Cədvəl";

$dil['Səhifələr / Səhifələrin siyahısı']['az']="Səhifələr / Səhifələrin siyahısı";
$dil['Səhifələr / Səhifələrin siyahısı']['ru']="Səhifələr / Səhifələrin siyahısı";
$dil['Səhifələr / Səhifələrin siyahısı']['en']="Səhifələr / Səhifələrin siyahısı";

$dil['silməyə_əminsiniz']['az']="Siz bu səhifəni silməyə əminsiniz ??";
$dil['silməyə_əminsiniz']['ru']="Siz bu səhifəni silməyə əminsiniz ??";
$dil['silməyə_əminsiniz']['en']="Siz bu səhifəni silməyə əminsiniz ??";

$dil['Yeni_albom']['az']="Yeni albom";
$dil['Yeni_albom']['ru']="Yeni albom";
$dil['Yeni_albom']['en']="Yeni albom";

$dil['Foto albomların']['az']="Banner  /  Foto albomların siyahısı";
$dil['Foto albomların']['ru']="Banner  /  Foto albomların siyahısı";
$dil['Foto albomlarını']['en']="Banner  /  Foto albomların siyahısı";

$dil['Redakte olundu']['az']="Redakte olundu!";
$dil['Redakte olundu']['ru']="Redakte olundu!";
$dil['Redakte olundu']['en']="Redakte olundu!";

$dil['redaktə et']['az']="Səhifəni redaktə et";
$dil['redaktə et']['ru']="Səhifəni redaktə et";
$dil['redaktə et']['en']="Səhifəni redaktə et";

$dil['Seçin']['az']="Seçin";
$dil['Seçin']['ru']="Seçin";
$dil['Seçin']['en']="Seçin";

$dil['Əsas menu']['az']="Əsas menu";
$dil['Əsas menu']['ru']="Əsas menu";
$dil['Əsas menu']['en']="Əsas menu";

$dil['Name']['az']="Name";
$dil['Name']['ru']="Name";
$dil['Name']['en']="Name";

$dil['Text']['az']="Text";
$dil['Text']['ru']="Text";
$dil['Text']['en']="Text";

$dil['Redaktə et2']['az']="Redaktə et";
$dil['Redaktə et2']['ru']="Redaktə et";
$dil['Redaktə et2']['en']="Redaktə et";

$dil['Yeni dil']['az']="Yeni dil";
$dil['Yeni dil']['ru']="Yeni dil";
$dil['Yeni dil']['en']="Yeni dil";

$dil['Admin  /  Dil']['az']="Admin  /  Dil";
$dil['Admin  /  Dil']['ru']="Admin  /  Dil";
$dil['Admin  /  Dil']['en']="Admin  /  Dil";

$dil['Yeni kateqoriya']['az']="Yeni kateqoriya";
$dil['Yeni kateqoriya']['ru']="Yeni kateqoriya";
$dil['Yeni kateqoriya']['en']="Yeni kateqoriya";

$dil['Məhsullar / Kateqoriyalar']['az']="Məhsullar / Kateqoriyalar";
$dil['Məhsullar / Kateqoriyalar']['ru']="Məhsullar / Kateqoriyalar";
$dil['Məhsullar / Kateqoriyalar']['en']="Məhsullar / Kateqoriyalar";

$dil['Asagi Sehifeler']['az']="Asagi Sehifeler";
$dil['Asagi Sehifeler']['ru']="Asagi Sehifeler";
$dil['Asagi Sehifeler']['en']="Asagi Sehifeler";

$dil['Yeni Admin']['az']="Yeni Admin";
$dil['Yeni Admin']['ru']="Yeni Admin";
$dil['Yeni Admin']['en']="Yeni Admin";


$dil['İstifadəçi adı']['az']="İstifadəçi adı";
$dil['İstifadəçi adı']['ru']="İstifadəçi adı";
$dil['İstifadəçi adı']['en']="İstifadəçi adı";


$dil['Idarə']['az']="Idarə";
$dil['Idarə']['ru']="Idarə";
$dil['Idarə']['en']="Idarə";

$dil['Admin  /  Administratorların siyahısı']['az']="Admin  /  Administratorların siyahısı";
$dil['Admin  /  Administratorların siyahısı']['ru']="Admin  /  Administratorların siyahısı";
$dil['Admin  /  Administratorların siyahısı']['en']="Admin  /  Administratorların siyahısı";

$dil['Düzəliş etmək istəyirəm']['az']="Düzəliş etmək istəyirəm";
$dil['Düzəliş etmək istəyirəm']['ru']="Düzəliş etmək istəyirəm";
$dil['Düzəliş etmək istəyirəm']['en']="Düzəliş etmək istəyirəm";

$dil['Seçilmişləri yerinə yetir']['az']="Seçilmişləri yerinə yetir";
$dil['Seçilmişləri yerinə yetir']['ru']="Seçilmişləri yerinə yetir";
$dil['Seçilmişləri yerinə yetir']['en']="Seçilmişləri yerinə yetir";


$dil['Birinci']['az']="Birinci";
$dil['Birinci']['ru']="Birinci";
$dil['Birinci']['en']="Birinci";

$dil['İrəli']['az']="İrəli";
$dil['İrəli']['ru']="İrəli";
$dil['İrəli']['en']="İrəli";

$dil['Geri']['az']="Geri";
$dil['Geri']['ru']="Geri";
$dil['Geri']['en']="Geri";

$dil['Sonuncu']['az']="Sonuncu";
$dil['Sonuncu']['ru']="Sonuncu";
$dil['Sonuncu']['en']="Sonuncu";

$dil['Məhsullar / Naviqasiyalar']['az']="Məhsullar / Naviqasiyalar";
$dil['Məhsullar / Naviqasiyalar']['ru']="Məhsullar / Naviqasiyalar";
$dil['Məhsullar / Naviqasiyalar']['en']="Məhsullar / Naviqasiyalar";

$dil['Yeni naviqasiya']['az']="Yeni naviqasiya";
$dil['Yeni naviqasiya']['ru']="Yeni naviqasiya";
$dil['Yeni naviqasiya']['en']="Yeni naviqasiya";

$dil['Səhifələr / Linklərin siyahısı']['az']="Səhifələr / Linklərin siyahısı";
$dil['Səhifələr / Linklərin siyahısı']['ru']="Səhifələr / Linklərin siyahısı";
$dil['Səhifələr / Linklərin siyahısı']['en']="Səhifələr / Linklərin siyahısı";

$dil['Yeni link']['az']="Yeni link";
$dil['Yeni link']['ru']="Yeni link";
$dil['Yeni link']['en']="Yeni link";

$dil['Gizli Sehifeler']['az']="Gizli Sehifeler";
$dil['Gizli Sehifeler']['ru']="Gizli Sehifeler";
$dil['Gizli Sehifeler']['en']="Gizli Sehifeler";

$dil['Şifrə']['az']="Şifrə";
$dil['Şifrə']['ru']="Şifrə";
$dil['Şifrə']['en']="Şifrə";

$dil['Mesaj']['az']="Mesaj";
$dil['Mesaj']['ru']="Mesaj";
$dil['Mesaj']['en']="Mesaj";

$dil['Göndər']['az']="Göndər";
$dil['Göndər']['ru']="Göndər";
$dil['Göndər']['en']="Göndər";

$dil['Hamiya']['az']="Hamiya";
$dil['Hamiya']['ru']="Hamiya";
$dil['Hamiya']['en']="Hamiya";

$dil['Yeni Mesaj']['az']="Yeni Mesaj";
$dil['Yeni Mesaj']['ru']="Yeni Mesaj";
$dil['Yeni Mesaj']['en']="Yeni Mesaj";

$dil['Faylı seçin']['az']="Faylı seçin";
$dil['Faylı seçin']['ru']="Faylı seçin";
$dil['Faylı seçin']['en']="Faylı seçin";

$dil['Yeni slide']['az']="Yeni slide əlavə et";
$dil['Yeni slide']['ru']="Yeni slide əlavə et";
$dil['Yeni slide']['en']="Yeni slide əlavə et";

$dil['Şəkli seç']['az']="Şəkli seç";
$dil['Şəkli seç']['ru']="Şəkli seç";
$dil['Şəkli seç']['en']="Şəkli seç";

$dil['Məhsulu redaktə et']['az']="Məhsulu redaktə et";
$dil['Məhsulu redaktə et']['ru']="Məhsulu redaktə et";
$dil['Məhsulu redaktə et']['en']="Məhsulu redaktə et";

$dil['Slider']['az']="Slider";
$dil['Slider']['ru']="Slider";
$dil['Slider']['en']="Slider";

$dil['Ardıcıllıq']['az']="Ardıcıllıq";
$dil['Ardıcıllıq']['ru']="Ardıcıllıq";
$dil['Ardıcıllıq']['en']="Ardıcıllıq";

$dil['kateqoriyanı seçin']['az']="Zəhmət olmasa kateqoriyanı seçin";
$dil['kateqoriyanı seçin']['ru']="Zəhmət olmasa kateqoriyanı seçin";
$dil['kateqoriyanı seçin']['en']="Zəhmət olmasa kateqoriyanı seçin";

$dil['Əlavə olundu']['az']="Əlavə olundu";
$dil['Əlavə olundu']['ru']="Əlavə olundu";
$dil['Əlavə olundu']['en']="Əlavə olundu";

$dil['Yeni məhsul əlavə et']['az']="Yeni məhsul əlavə et";
$dil['Yeni məhsul əlavə et']['ru']="Yeni məhsul əlavə et";
$dil['Yeni məhsul əlavə et']['en']="Yeni məhsul əlavə et";

$dil['Menyu']['az']="Menyu";
$dil['Menyu']['ru']="Menyu";
$dil['Menyu']['en']="Menyu";

$dil['Premier']['az']="Premier";
$dil['Premier']['ru']="Premier";
$dil['Premier']['en']="Premier";

$dil['Qısa mətin']['az']="Qısa mətin";
$dil['Qısa mətin']['ru']="Qısa mətin";
$dil['Qısa mətin']['en']="Qısa mətin";

$dil['description']['az']="description";
$dil['description']['ru']="description";
$dil['description']['en']="description";

$dil['keyword']['az']="keyword";
$dil['keyword']['ru']="keyword";
$dil['keyword']['en']="keyword";

$dil['url_tag']['az']="url_tag";
$dil['url_tag']['ru']="url_tag";
$dil['url_tag']['en']="url_tag";

$dil['silindi']['az']="silindi";
$dil['silindi']['ru']="silindi";
$dil['silindi']['en']="silindi";

$dil['Ana səhifədə olaacaq']['az']="Ana səhifədə olaacaq";
$dil['Ana səhifədə olaacaq']['ru']="Ana səhifədə olaacaq";
$dil['Ana səhifədə olaacaq']['en']="Ana səhifədə olaacaq";

$dil['Passiv olundu']['az']="Passiv olundu";
$dil['Passiv olundu']['ru']="Passiv olundu";
$dil['Passiv olundu']['en']="Passiv olundu";

$dil['Aktiv olundu']['az']="Aktiv olundu";
$dil['Aktiv olundu']['ru']="Aktiv olundu";
$dil['Aktiv olundu']['en']="Aktiv olundu";

$dil['Sıralama yerinə yetirildi']['az']="Sıralama yerinə yetirildi";
$dil['Sıralama yerinə yetirildi']['ru']="Sıralama yerinə yetirildi";
$dil['Sıralama yerinə yetirildi']['en']="Sıralama yerinə yetirildi";

$dil['Yeni səhifə əlavə et']['az']="Yeni səhifə əlavə et";
$dil['Yeni səhifə əlavə et']['ru']="Yeni səhifə əlavə et";
$dil['Yeni səhifə əlavə et']['en']="Yeni səhifə əlavə et";

$dil['Yuxari']['az']="Yuxari";
$dil['Yuxari']['ru']="Yuxari";
$dil['Yuxari']['en']="Yuxari";

$dil['Asagi']['az']="Asagi";
$dil['Asagi']['ru']="Asagi";
$dil['Asagi']['en']="Asagi";

$dil['Gizli']['az']="Gizli";
$dil['Gizli']['ru']="Gizli";
$dil['Gizli']['en']="Gizli";

$dil['Dəyişdir']['az']="Dəyişdir";
$dil['Dəyişdir']['ru']="Dəyişdir";
$dil['Dəyişdir']['en']="Dəyişdir";

$dil['Əlavə et']['az']="Əlavə et";
$dil['Əlavə et']['ru']="Əlavə et";
$dil['Əlavə et']['en']="Əlavə et";

$dil['Status']['az']="Status";
$dil['Status']['ru']="Status";
$dil['Status']['en']="Status";

$dil['Tip']['az']="Tip";
$dil['Tip']['ru']="Tip";
$dil['Tip']['en']="Tip";

$dil['Foto']['az']="Foto";
$dil['Foto']['ru']="Foto";
$dil['Foto']['en']="Foto";

$dil['Video']['az']="Video";
$dil['Video']['ru']="Video";
$dil['Video']['en']="Video";

$dil['Yeni gallery']['az']="Yeni gallery əlavə et";
$dil['Yeni gallery']['ru']="Yeni gallery əlavə et";
$dil['Yeni gallery']['en']="Yeni gallery əlavə et";

$dil['Gallery redaktə et']['az']="Gallery redaktə et";
$dil['Gallery redaktə et']['ru']="Gallery redaktə et";
$dil['Gallery redaktə et']['en']="Gallery redaktə et";

$dil['Gallery']['az']="Gallery";
$dil['Gallery']['ru']="Gallery";
$dil['Gallery']['en']="Gallery";

$dil['Yeni kateqoriya əlavə et']['az']="Yeni kateqoriya əlavə et";
$dil['Yeni kateqoriya əlavə et']['ru']="Yeni kateqoriya əlavə et";
$dil['Yeni kateqoriya əlavə et']['en']="Yeni kateqoriya əlavə et";

$dil['Kateqoriya']['az']="Kateqoriya";
$dil['Kateqoriya']['ru']="Kateqoriya";
$dil['Kateqoriya']['en']="Kateqoriya";

$dil['Əsas kateqoriya']['az']="Əsas kateqoriya";
$dil['Əsas kateqoriya']['ru']="Əsas kateqoriya";
$dil['Əsas kateqoriya']['en']="Əsas kateqoriya";

$dil['Yeni dil əlavə et']['az']="Yeni dil əlavə et";
$dil['Yeni dil əlavə et']['ru']="Yeni dil əlavə et";
$dil['Yeni dil əlavə et']['en']="Yeni dil əlavə et";

$dil['Dil boş']['az']="Dil xanasını boş buraxmaq olmaz";
$dil['Dil boş']['ru']="Dil xanasını boş buraxmaq olmaz";
$dil['Dil boş']['en']="Dil xanasını boş buraxmaq olmaz";

$dil['Əsas dil olsun']['az']="Əsas dil olsun";
$dil['Əsas dil olsun']['ru']="Əsas dil olsun";
$dil['Əsas dil olsun']['en']="Əsas dil olsun";

$dil['Dillər']['az']="Dillər";
$dil['Dillər']['ru']="Dillər";
$dil['Dillər']['en']="Dillər";

$dil['şəkil əlavə et']['az']="şəkil əlavə et";
$dil['şəkil əlavə et']['ru']="şəkil əlavə et";
$dil['şəkil əlavə et']['en']="şəkil əlavə et";

$dil['Düzəliş et']['az']="Düzəliş et";
$dil['Düzəliş et']['ru']="Düzəliş et";
$dil['Düzəliş et']['en']="Düzəliş et";

$dil['İmtina olundu']['az']="İmtina olundu";
$dil['İmtina olundu']['ru']="İmtina olundu";
$dil['İmtina olundu']['en']="İmtina olundu";

$dil['dil aktiv etməyə']['az']="Siz bu səhifəni aktiv etməyə əminsiniz";
$dil['dil aktiv etməyə']['ru']="Siz bu səhifəni aktiv etməyə əminsiniz";
$dil['dil aktiv etməyə']['en']="Siz bu səhifəni aktiv etməyə əminsiniz";

$dil['dil passiv etməyə']['az']="Siz bu səhifəni passiv etməyə əminsiniz";
$dil['dil passiv etməyə']['ru']="Siz bu səhifəni passiv etməyə əminsiniz";
$dil['dil passiv etməyə']['en']="Siz bu səhifəni passiv etməyə əminsiniz";

$dil['Sol']['az']="Sol";
$dil['Sol']['ru']="Sol";
$dil['Sol']['en']="Sol";

$dil['Yeni_link']['az']="Yeni link";
$dil['Yeni_link']['ru']="Yeni link";
$dil['Yeni_link']['en']="Yeni link";

$dil['linkler']['az']="Linkler";
$dil['linkler']['ru']="Linkler";
$dil['linkler']['en']="Linkler";

$dil['jurnal']['az']="jurnal";
$dil['jurnal']['ru']="jurnal";
$dil['jurnal']['en']="jurnal";
$dil['yeni_jurnal']['az']="Yeni jurnal";
$dil['yeni_jurnal']['ru']="Yeni jurnal";
$dil['yeni_jurnal']['en']="Yeni jurnal";

$dil['Nömre']['az']="Nömre";
$dil['Nömre']['ru']="Nömre";
$dil['Nömre']['en']="Nömre";

$dil['Fayli seç']['az']="Fayli seç";
$dil['Fayli seç']['ru']="Fayli seç";
$dil['Fayli seç']['en']="Fayli seç";


$dil['reklam']['az']="Reklam";
$dil['reklam']['ru']="Reklam";
$dil['reklam']['en']="Reklam";

$dil['email']['az']="Email";
$dil['email']['ru']="Email";
$dil['email']['en']="Email";

$dil['Yeni_reklam']['az']="Yeni reklam";
$dil['Yeni_reklam']['ru']="Yeni reklam";
$dil['Yeni_reklam']['en']="Yeni reklam";

$dil['Yeni_email']['az']="Yeni email";
$dil['Yeni_email']['ru']="Yeni email";
$dil['Yeni_email']['en']="Yeni email";






















?>