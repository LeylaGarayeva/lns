<?php die(); ?>
gc start at 02/Feb/2015 16:12:20
