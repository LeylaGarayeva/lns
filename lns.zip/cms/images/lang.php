﻿<?PHP

$dil['bottom']['az']="Copyright © 2011. Əmək və Əhalinin Sosial Müdafiəsi Nazirliyi !";
$dil['bottom']['ru']="Copyright © 2011. Əmək və Əhalinin Sosial Müdafiəsi Nazirliyi !";
$dil['bottom']['en']="Copyright © 2011. Əmək və Əhalinin Sosial Müdafiəsi Nazirliyi !";



$dil['read']['az']="daha &#601;trafl&#305;...";
$dil['read']['ru']="подробнее...";
$dil['read']['en']="read more...";

$dil['back']['az']="<< geri qay&#305;t";
$dil['back']['ru']="<< назад";
$dil['back']['en']="<< back";


$dil['search']['az']="Axtar";
$dil['search']['ru']="Поиск";
$dil['search']['en']="Search";




$dil['kalendar_1']['az']="Be";
$dil['kalendar_1']['ru']="Be";
$dil['kalendar_1']['en']="Be";

$dil['kalendar_2']['az']="Ça";
$dil['kalendar_2']['ru']="Ça";
$dil['kalendar_2']['en']="Ça";

$dil['kalendar_3']['az']="Ç";
$dil['kalendar_3']['ru']="Ç";
$dil['kalendar_3']['en']="Ç";

$dil['kalendar_4']['az']="Ca";
$dil['kalendar_4']['ru']="Ca";
$dil['kalendar_4']['en']="Ca";

$dil['kalendar_5']['az']="C";
$dil['kalendar_5']['ru']="C";
$dil['kalendar_5']['en']="C";

$dil['kalendar_6']['az']="Ş";
$dil['kalendar_6']['ru']="Ş";
$dil['kalendar_6']['en']="Ş";

$dil['kalendar_7']['az']="B";
$dil['kalendar_7']['ru']="B";
$dil['kalendar_7']['en']="B";



////////////////////////////////////////////////////Elektron forma  ///////////////////////////////////////

$dil['forma_bash']['az']="Elektron m&#252;raci&#601;t";
$dil['forma_bash']['ru']="Elektron m&#252;raci&#601;t";
$dil['forma_bash']['en']="Elektron m&#252;raci&#601;t";

$dil['forma_ad']['az']="Ad";
$dil['forma_ad']['ru']="Имя";
$dil['forma_ad']['en']="Name";

$dil['forma_soyad']['az']="Soyad";
$dil['forma_soyad']['ru']="Фамилия";
$dil['forma_soyad']['en']="Surname";

$dil['forma_tel']['az']="Tel";
$dil['forma_tel']['ru']="Тел";
$dil['forma_tel']['en']="Tel";

$dil['sual']['az']="Sual";
$dil['sual']['ru']="Вопрос";
$dil['sual']['en']="Question";

$dil['forma_send']['az']="G&#246;nd&#601;r";
$dil['forma_send']['ru']="Послать";
$dil['forma_send']['en']="Send";

$dil['forma_sil']['az']="Sil";
$dil['forma_sil']['ru']="Удалять";
$dil['forma_sil']['en']="Delete";

$dil['forma_gonderilme']['az']="G&#246;nd&#601;rildi:";
$dil['forma_gonderilme']['ru']="Отправлено";
$dil['forma_gonderilme']['en']="Sent";

$dil['forma_gonderilmedi']['az']="G&#246;nd&#601;rilm&#601;di:";
$dil['forma_gonderilmedi']['ru']="Не отправлено:";
$dil['forma_gonderilmedi']['en']="It can't be sent:";

$dil['error']['az']="Zəhmət olmasa xanaları sona qədər doldurun:";
$dil['error']['ru']="Пожалуйста заполните поля:";
$dil['error']['en']="Please fill shown patterns:";
?>